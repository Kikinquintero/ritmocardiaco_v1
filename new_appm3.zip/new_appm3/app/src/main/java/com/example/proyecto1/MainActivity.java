package com.example.proyecto1;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.wearable.activity.WearableActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.util.concurrent.ThreadLocalRandom;

import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.app.NotificationCompat.WearableExtender;

import static android.provider.CalendarContract.EXTRA_EVENT_ID;

public class MainActivity extends WearableActivity {
    private static final String chanel_id="canal";
    private PendingIntent pendingIntent;

    private static final String TAG = "MainActivity";
    final Handler handler= new Handler();
    Runnable updateRunnable;

    private SensorManager mSensorManager;
    private Sensor mHeartRateSensor;

    private Button btnInicio;
    private boolean readerActivated = false;
    private TextView txtcardiaco;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final DecimalFormat format = new DecimalFormat("#.00");// el numero de ceros despues del entero
        setAmbientEnabled();

        btnInicio = findViewById(R.id.btnInicio);
        txtcardiaco = findViewById(R.id.txtcardiaco);

        btnInicio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!readerActivated) {
                    btnInicio.setBackgroundColor(Color.GREEN);
                    btnInicio.setText("Finalizar");
                    readerActivated = true;

                        ejecutar();
                }
                else {
                    btnInicio.setBackgroundColor(Color.GRAY);
                    btnInicio.setText("Iniciar");
                    readerActivated = false;
//                    stopDatosSensor();
                    txtcardiaco.setText("-");
                    handler.removeCallbacks(updateRunnable);

                }

            }
        });

//


        /////
           
    }

    private void ejecutar(){

        handler.postDelayed( updateRunnable = new Runnable(){
            @Override
            public void run() {
                startDatosSensor();//llamamos nuestro metodo
                handler.postDelayed(this,3000);//se ejecutara cada 3 segundos

            }
        },3000);//empezara a ejecutarse después de 3 segundos
    }








    private void startDatosSensor() {
            int numero = ThreadLocalRandom.current().nextInt(0, 200 + 1);
            txtcardiaco.setText("" + numero);

            if(numero <40){
                if( Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ){
                    muestranotificacion();
                }else{
                    muestranuevanotificacion();
                }
            }
    }



    private void muestranuevanotificacion() {
        setPendingIntent(MainActivity.class);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext(),

                chanel_id)
                .setSmallIcon(R.mipmap.ic_heart)
                .setContentTitle("Ritmo Cardiaco")
                .setContentText("Su salud esta en riesgo, acuda a su médico urgentemente")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pendingIntent);
        NotificationManagerCompat notificationManager=NotificationManagerCompat.from(getApplicationContext());
        notificationManager.notify(1,builder.build());
    }

    private void setPendingIntent(Class<?> clsActivity ) {
        Intent intent=new Intent(this,clsActivity);
        TaskStackBuilder stateBuilder= TaskStackBuilder.create(this);
        stateBuilder.addParentStack(clsActivity);
        stateBuilder.addNextIntent(intent);
        pendingIntent=stateBuilder.getPendingIntent(1,PendingIntent.FLAG_UPDATE_CURRENT);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void muestranotificacion() {
        NotificationChannel canal=new NotificationChannel(chanel_id,"NEW",
                NotificationManager.IMPORTANCE_DEFAULT);
        NotificationManager manager= (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        manager.createNotificationChannel(canal);
        muestranuevanotificacion();
    }









}